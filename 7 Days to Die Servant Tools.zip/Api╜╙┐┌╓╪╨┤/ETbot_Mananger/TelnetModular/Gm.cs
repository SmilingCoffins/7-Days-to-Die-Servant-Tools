﻿using ETbot_Mananger.Controls;
using ETbot_Mananger.HttpServerSlr.TelnetThreadIntface;
using System;
using System.Xml;
/*
 * 接口名：购买
 * 作用：玩家输入购买指令，寻找对应物品，找到判断积分是否足够，足够则发放物品，不够则提示积分不足，找到不到物品则提示输入错误
 */
namespace ETbot_Mananger.Telnet
{
	class Gm : TelnetThread
	{
		public override void run()
		{
			SetPath("home.xml");
			string id = getID();
			string val = getVal();

			string[] _pat = val.Split(' ');
			if (_pat.Length != 2)
			{
				pmSend("请检查参数是否正确！");
				return;
			}

			string Itemid = _pat[1];        //物品ID
			int ItemJifen = -1;             //物品积分
			string Item = "";               //物品名称
			string len = "";                //物品数量
		 
			XmlNode list = GetXml("SHOP");
			XmlNodeList zi = list.ChildNodes;

			foreach(XmlNode p in zi)
			{
				if(p.Attributes[0].Value == Itemid)
				{
					ItemJifen = (int)Double.Parse(p.Attributes[2].Value);
					Item = p.Attributes[1].Value;
					len = p.Attributes[3].Value;
				}
			}

			if(ItemJifen < 0 || Item == "" || len == "")
			{
				pmSend("请检查物品id是否正确！");
				return;
			}

			list = GetXml("JIFEN");
			zi = list.ChildNodes;

			foreach(XmlNode p in zi)
			{
				if(p.Attributes[0].Value == id)
				{
					int playerJi = (int)Double.Parse(p.InnerText);
					if(playerJi >= ItemJifen)
					{
						playerJi = playerJi - ItemJifen;
						p.InnerText = playerJi + "";
						API.telnet.Send("give " + id + " " + Item + " " + len);
						pmSend("物品已发送！");
						appSetting.Save(API.GamePath + "home.xml");
						return;
					}
					else
					{
						pmSend("积分不足！");
						return;
					}
				}
			}

			pmSend("请检查是否开启积分功能！");

		}

		public string getVal()
		{
			string buff = str;
			while(buff.IndexOf(": ") != -1)
			{
				buff = buff.Substring(buff.IndexOf(": ") + 2);
			}

			return buff.Substring(0, buff.IndexOf("\r\n"));
		}

		public override string Name()
		{
			return "购买";
		}
	}
}
