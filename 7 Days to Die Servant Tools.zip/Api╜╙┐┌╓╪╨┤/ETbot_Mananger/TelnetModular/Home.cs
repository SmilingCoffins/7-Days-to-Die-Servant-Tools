﻿using ETbot_Mananger.Controls;
using ETbot_Mananger.HttpServerSlr.TelnetThreadIntface;
using System.Threading;
using System.Xml;
/*
 * 接口名：回城
 * 作用：玩家输入回城指令，在xml中寻找对应的pos坐标，找到则传送，找不到则提示用户先/sethome
 */
namespace ETbot_Mananger.Telnet
{
    class Home : TelnetThread
    {
        public override string Name()
        {
            return "回城";
        }

        public override void run()
        {

            pmSend("十秒后传送");

            Thread.Sleep(10000);

            SetPath("home.xml");

            XmlNodeList list = GetXml("HOME").ChildNodes;

            string str = getID();

            foreach (XmlNode p in list)
            {
                if (p.Attributes[0].Value == str)
                {
                    API.telnet.Send("tele " + str + " " + p.InnerText);
                    return;
                }
            }

            pmSend("未设置回城位置");


        }

        
    }
}
