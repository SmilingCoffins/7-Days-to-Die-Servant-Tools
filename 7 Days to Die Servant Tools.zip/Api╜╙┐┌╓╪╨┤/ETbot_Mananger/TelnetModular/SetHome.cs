﻿using ETbot_Mananger.HttpServerSlr.TelnetThreadIntface;
using System;
using System.Collections.Generic;
using System.Xml;
/*
 * 接口名：设置回城
 * 作用：玩家输入设置回城指令，添加坐标
 */
namespace ETbot_Mananger.Telnet
{
    class SetHome : TelnetThread
    {
        public override void run()
        {
            SetPath("home.xml");
            string id = getID();
            XmlNode list = GetXml("HOME");
            XmlNodeList i = list.ChildNodes;
            foreach (XmlNode p in i)
            {
                if(p.Attributes[0].Value == id) { 
                    p.InnerText = getPosSplit(getpos(id));
                    appSetting.Save(path);
                    pmSend("设置回城成功！");
                    return;
                }
            }

            XmlElement elem = appSetting.CreateElement("name");
            string pos = getpos(id);
            elem.InnerText = getPosSplit(pos);
            elem.SetAttribute("id", getID());
            list.AppendChild(elem);
            appSetting.Save(path);

            pmSend("设置回城成功！");
            
        }

        private string getpos(string id)
        {
			List<EntityPlayer> list = GameManager.Instance.World.Players.list;
			for (int i = 0; i < list.Count; i++)
			{
				EntityPlayer entityPlayer = list[i];
				string value = "<unknown>";
				string value2 = "<unknown>";
				ClientInfo clientInfo = SingletonMonoBehaviour<ConnectionManager>.Instance.Clients.ForEntityId(entityPlayer.entityId);
				if (clientInfo != null)
				{
					value = clientInfo.ip;
					value2 = clientInfo.playerId;
				}
                //stringBuilder.Append("游戏ID=");
                if (entityPlayer.entityId + "" == id)
                {
                    return entityPlayer.GetPosition().ToCultureInvariantString();
                }
					
			}

            return "";
			
		}

        public string getPosSplit(string str)
        {
            str = str.Substring(str.IndexOf("(") + 1);
            str = str.Substring(0, str.IndexOf(")"));

            string[] val = str.Split(new char[] { ',', ' ' });

            return (int)Double.Parse(val[0]) + " " + (int)Double.Parse(val[2]) + " " + (int)Double.Parse(val[4]);
        }

        public override string Name()
        {
            return "设置回城";
        }
    }
}
