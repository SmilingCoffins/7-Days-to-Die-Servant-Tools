﻿using ETbot_Mananger.Controls;
using ETbot_Mananger.HttpServerSlr.TelnetThreadIntface;
using System.Collections.Generic;

namespace ETbot_Mananger.Telnet
{
    class PlayerRequ : TelnetThread
    {
        public override string Name()
        {
            return "接受传送";
        }

        public override void run()
        {
            string id = getID();
            if (API.val.ContainsKey(id))
            {
                API.telnet.Send("tele " + API.val[id] + " " + id);
                API.val.Remove(id);
                pmSend("接受成功！");
            }
            else
            {
                pmSend("无玩家传送，或等待时间超过十秒！");
            }
        }

        
    }
}
