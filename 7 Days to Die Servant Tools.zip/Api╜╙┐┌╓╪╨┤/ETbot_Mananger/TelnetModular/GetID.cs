﻿using ETbot_Mananger.HttpServerSlr.TelnetThreadIntface;
using System.Collections.Generic;
using System.Threading;

namespace ETbot_Mananger.Telnet
{
    class GetID : TelnetThread
    {
        public override string Name()
        {
            return "获取玩家短ID";
        }

        public override void run()
        {
			List<EntityPlayer> list = GameManager.Instance.World.Players.list;
			if (list != null)
			{
				for (int i = 0; i < list.Count; i++)
				{
					EntityPlayer entityPlayer = list[i];
					pmSend("ID:"+entityPlayer.entityId + ",玩家名:" + entityPlayer.EntityName);
					Thread.Sleep(200);
				}
			}
		}
    }
}
