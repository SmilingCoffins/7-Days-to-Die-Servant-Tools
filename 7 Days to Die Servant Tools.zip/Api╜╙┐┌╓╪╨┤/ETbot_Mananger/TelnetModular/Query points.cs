﻿using ETbot_Mananger.HttpServerSlr.TelnetThreadIntface;
using System.Xml;
/*
 * 接口名：积分
 * 作用：玩家输入积分指令，返回积分
 */
namespace ETbot_Mananger.Telnet
{
    class QueryPoints : TelnetThread
    {
        public override string Name()
        {
            return "积分";
        }

        public override void run()
        {
            SetPath("home.xml");
            string id = getID();

            XmlNode list = GetXml("JIFEN");
            XmlNodeList zi = list.ChildNodes;
            foreach(XmlNode p in zi)
            {
                if(p.Attributes[0].Value == id)
                {
                    pmSend("您的积分为" + p.InnerText);
                    return;
                }
            }

            XmlElement em = appSetting.CreateElement("name");
            em.InnerText = "0";
            em.SetAttribute("id", id);
            em.SetAttribute("riqi", "");

            list.AppendChild(em);
            appSetting.Save(path);

            pmSend("您的积分为：" + em.InnerText);
        }
    }
}
