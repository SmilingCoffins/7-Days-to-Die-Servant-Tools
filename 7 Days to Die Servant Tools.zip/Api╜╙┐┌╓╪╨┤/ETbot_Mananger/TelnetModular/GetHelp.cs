﻿using ETbot_Mananger.HttpServerSlr.TelnetThreadIntface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;

namespace ETbot_Mananger.TelnetModular
{
    class GetHelp : TelnetThread
    {
        public override string Name()
        {
            return "帮助";
        }

        public override void run()
        {
            string id = getID();
            SetPath("home.xml");

            XmlNode list = GetXml("FUNCTION");

            XmlNodeList p = list.ChildNodes;

            foreach(XmlNode p2 in p)
            {
                pmSend("指令：" + p2.InnerText + ",功能：" + p2.Attributes[0].Value);
                Thread.Sleep(200);
            }
        }
    }
}
