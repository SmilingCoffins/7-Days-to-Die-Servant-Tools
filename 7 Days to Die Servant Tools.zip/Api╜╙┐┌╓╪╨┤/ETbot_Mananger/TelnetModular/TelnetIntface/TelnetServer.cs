﻿using ETbot_Mananger.Controls;
using ETbot_Mananger.HttpServerSlr.TelnetThreadIntface;
using Http.HttpServerSlr;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Xml;

namespace ETbot_Mananger.HttpServerSlr
{
    class TelnetServer : HttpServer_Intface
	{
		Socket socket;			//telnet socket客户端
		public StringBuilder buf = new StringBuilder();	//准备存放的telnet日志
		public XmlDocument appSetting = new XmlDocument();	//xml的doc
		public XmlNode pXmlNode;
		Dictionary<string, Type> val = new Dictionary<string, Type>();	//val 获取TelnetThread类下的名 和 对应的类

		public override void run()
		{

			initZ();	//初始化val 将telnetthread下的所有实现类，进行获取name 再从home.xml中判断这个name是否存在，存在则获取对应的指令名 添加进
						//val中，这个函数就相当于，重新绑定了 指令 与 对应处理类之间的关系


			//获取IP 端口 密码
			string[] data = GetIP(API.GamePath + "Telnet.xml");

			IPEndPoint ipep = new IPEndPoint(IPAddress.Parse(data[0]), int.Parse(data[1]));
			socket = new Socket(ipep.AddressFamily, SocketType.Stream, ProtocolType.Tcp) ;
			
			socket.Connect(ipep);           //开启链接


			string buff = "";				//socket接受数据有时会接受不全，会出现一半的情况，已知telnet的格式为msg\r\n
											//所以判断buff里有没有\r\n 就可知这条数据是否完整   防止数据不全，错过对应信息
			while (true)
			{

				byte[] by = new byte[1024];
				int len = socket.Receive(by);

				
				string str = System.Text.Encoding.UTF8.GetString(by, 0, len);		//将接受到的byte 转换成string
				buff += str;														//把str 加给buff 在判断buff 内有没有 \r\n

				

				if (buff.IndexOf("\r\n")!=-1)
				{
					buf.Append(buff);

					if (buff .IndexOf("Please enter password:")!=-1)                //如果参数为 Please enter password:  则输入密码
					{
						Send(data[2]);												//发送密码
					}

					if (buff.IndexOf("entity id") != -1)                            //如果buff中有entity id 则代表玩家输入数据 所以对数据进行处理
					{
						string temp = buff;                                             //准备做参数处理
						while (temp.IndexOf(": ") != -1)								//先得到用户输入的指令
						{
							temp = temp.Substring(temp.IndexOf(": ") + 2);
						}

						temp = temp.Substring(0, temp.IndexOf("\r\n"));					//这里得到的指令不完全，所以需要将最后的\r\n处理掉

						if(temp.IndexOf(" ") != -1)										//如用户输入的是多段指令 如 /gm 1则需要识别出/gm
                        {
							string[] t = temp.Split(' ');

                            if (val.ContainsKey(t[0]))									//从val中找对应的类
                            {
								Object Se = Activator.CreateInstance(val[t[0]]);		//实例化此类

								MethodInfo method = val[t[0]].GetMethod("Start");		//从类中取出 start方法

								object[] obj =
								{
									buff
								};

								method.Invoke(Se, obj);									//对方法加参，运行，start方法中 默认开启一条线程处理，防止抛出异常导致telnet线程销毁
                            }

                        }
                        else//如果不是多段消息，则直接将消息 给val进行查找
                        {
							if (val.ContainsKey(temp))
							{
								Object Se = Activator.CreateInstance(val[temp]);

								Log.Out("#调试:" + temp);

								MethodInfo method = val[temp].GetMethod("Start");//functionname:方法名字

								object[] obj =
								{
									buff
								};

								method.Invoke(Se, obj);
							}
						}
						
					}
					buff = "";															//这条消息处理完了，把buff清空，重新接受消息，等待完整消息的生成
				}

				Thread.Sleep(60);

			}

		}

		//获取对应节点的xmlnode
		public XmlNode GetXml(string id)
		{
			appSetting = new XmlDocument();
			appSetting.Load(API.GamePath + "home.xml");

			pXmlNode = appSetting.DocumentElement;
			foreach (XmlNode p in pXmlNode)
			{
				if (p.Name == id)
				{
					return p;
				}
			}

			return null;
		}
		//重新绑定，指令 与 类
		public void initZ()
        {

			Dictionary<string, Type> list = LoadBuffScript(typeof(TelnetThread));

			val.Clear();
			
			//通过键的集合取

			foreach (string key in list.Keys)

			{

				Object Se = Activator.CreateInstance(list[key]);

				MethodInfo method = list[key].GetMethod("Name");//functionname:方法名字

				string str = (string)method.Invoke(Se, null);
				

				XmlNode li = GetXml("FUNCTION");
				XmlNodeList l = li.ChildNodes;

				

				bool i = true;

				foreach (XmlNode p in l)
                {
					if(p.Attributes[0].Value == str)
                    {
						i = false;
						if (p.Attributes[1].Value == "true")
						{
							val.Add(p.InnerText, list[key]);
						}
					}
                }
				
				if (i == true)
                {
					XmlElement em = appSetting.CreateElement("name");
					em.SetAttribute("id", str);
					em.SetAttribute("state", "true");
					em.InnerText = "/test";

					li.AppendChild(em);
					appSetting.Save(API.GamePath + "home.xml");
                }

				

			}

		}
		//发送消息给服务器
		public void Send(string _buf)
		{
			socket.Send(System.Text.Encoding.UTF8.GetBytes(_buf + "\r\n"));
		}
		//取出地址 端口 密码
		public string[] GetIP(string path)
		{
			XmlDocument appSetting = new XmlDocument();
			appSetting.Load(path);

			string[] str = new string[3];

			XmlNode pXmlNode = appSetting.DocumentElement;

			foreach (XmlNode p in pXmlNode)
			{
				if (p.Name == "Server")
				{
					XmlNodeList pXmlNodeList = p.ChildNodes;
					foreach (XmlNode p2 in pXmlNodeList)

					{

						if (p2.Name == "IP")
						{
							str[0] = p2.InnerText;
						}
						if (p2.Name == "PORT")
						{
							str[1] = p2.InnerText;
						}
						if (p2.Name == "PASSWD")
						{
							str[2] = p2.InnerText;
						}
					}
				}
			}

			return str;

		}
		//加载对应类的实现类
		private Dictionary<string, Type> LoadBuffScript(Type _type)
		{
			Dictionary<string, Type> list = new Dictionary<string, Type>();
			var types = Assembly.GetCallingAssembly().GetTypes();
			//var aType = typeof(IBuffControl);
			var aType = _type;
			foreach (var type in types)
			{
				var baseType = type.BaseType;  //获取基类
				while (baseType != null)  //获取所有基类
				{
					//Debug.Log(baseType.Name);
					if (baseType.Name == aType.Name)
					{
						Type objtype = Type.GetType(type.FullName, true);
						//object obj = Activator.CreateInstance(objtype);
						//if (obj != null)
						//{
						//SeekTarget info = obj as SeekTarget;
						list.Add(objtype.Name, objtype);
						//}
						break;
					}
					else
					{
						baseType = baseType.BaseType;
					}
				}

			}
			return list;
		}
	}
}
