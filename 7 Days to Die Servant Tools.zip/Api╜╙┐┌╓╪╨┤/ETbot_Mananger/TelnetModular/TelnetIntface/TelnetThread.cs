﻿
using ETbot_Mananger.Controls;
using System.Threading;
using System.Xml;

namespace ETbot_Mananger.HttpServerSlr
{

    namespace TelnetThreadIntface
    {
        public abstract class TelnetThread
        {

            public string path;             //插件对应的路径
            public string str;              //传入的消息 用户输入的消息
            public XmlDocument appSetting;  //xml的doc 根
            public XmlNode pXmlNode;        //初始化功能

            public void Start(string str)
            {
                this.str = str;
                Thread _thread = new Thread(new ThreadStart(run));       //启动Http服务器线程
                _thread.Start();

            }

            //设置path 值
            public void SetPath(string path)
            {
                this.path = API.GamePath+path;
            }

            public abstract void run();     //Http线程启动方法
            public abstract string Name();  //接口对应的方法名，如回城

            //获取玩家输入消息的id
            public string getID()
            {
                string temp = str;
                temp = temp.Substring(temp.IndexOf("ntity id") + 10);
                temp = temp.Substring(0, temp.IndexOf("'"));
                return temp;
            }
            //获取指定节点的xmlnode
            public XmlNode GetXml(string id)
            {
                appSetting = new XmlDocument();
                appSetting.Load(path);

                pXmlNode = appSetting.DocumentElement;
                foreach (XmlNode p in pXmlNode)
                {
                    if (p.Name == id)
                    {
                        return p;
                    }
                }

                return null;
            }
            //发送私信给玩家
            public void pmSend(string buf)
            {
                API.telnet.Send("pm " + getID() + " " + buf);
            }
        }
        
    }

    

}
