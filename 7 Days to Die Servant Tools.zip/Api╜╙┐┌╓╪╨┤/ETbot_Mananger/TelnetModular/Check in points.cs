﻿using ETbot_Mananger.HttpServerSlr.TelnetThreadIntface;
using System;
using System.Xml;
/*
 * 接口名：签到
 * 作用：玩家输入签到指令，获取积分
 */
namespace ETbot_Mananger.Telnet
{
    class CheckInPoints : TelnetThread
    {
        public override string Name()
        {
            return "签到";
        }

        public override void run()
        {
            SetPath("home.xml");
            string id = getID();

            XmlNode list = GetXml("JIFEN");
            XmlNodeList zi = list.ChildNodes;

            foreach(XmlNode p in zi)
            {
                if(p.Attributes[0].Value == id)
                {
                    if (p.Attributes[1].Value == DateTime.Now.ToString("M-d"))
                    {
                        pmSend("您已签到！");
                        return;
                    }
                    else
                    {
                        p.InnerText = (Double.Parse(p.InnerText) + 10) + "";
                        pmSend("您本次签到获得十积分！");
                        p.Attributes[1].Value = DateTime.Now.ToString("M-d");
                        appSetting.Save(path);
                        return;
                    }
                }
            }

            pmSend("您还未开启积分功能，请输入/jf开启积分功能!");
            return;

        }
    }
}
