﻿using ETbot_Mananger.Controls;
using ETbot_Mananger.HttpServerSlr.TelnetThreadIntface;
using System.Collections.Generic;
using System.Threading;

namespace ETbot_Mananger.Telnet
{
    class PlayerResp : TelnetThread
    {
        public override string Name()
        {
            return "请求传送";
        }

        public override void run()
        {
            string id = getID();
            string str = getVal();

            if(str.IndexOf(" ") != -1)
            {
                string[] sp = str.Split(' ');
                if (sp.Length != 2)
                {
                    pmSend("输入参数错误！");
                }
                else
                {
                    foreach (string s in API.val.Keys)
                    {
                        if(API.val[s] == id)
                        {
                            pmSend("十秒内只能请求传送一次");
                            return;
                        }
                    }

                    string RespId = sp[1];

                    string IdName = getName(id);
                    string RespIdName = getName(RespId);

                    if(RespIdName == "")
                    {
                        pmSend("请求的玩家不存在！");
                        return;
                    }

                    API.val.Add(RespId, id);
                    API.telnet.Send("pm " + RespId + " 玩家：" + IdName  + "请求传送，/tpc接受传送，十秒内有效！");
                    Thread.Sleep(10000);

                    if (API.val.ContainsKey(RespId))
                    {
                        API.val.Remove(RespId);
                    }
                }
            }
        }

        public string getVal()
        {
            string buff = str;
            while (buff.IndexOf(": ") != -1)
            {
                buff = buff.Substring(buff.IndexOf(": ") + 2);
            }

            return buff.Substring(0, buff.IndexOf("\r\n"));
        }

        public string getName(string id)
        {
            List<EntityPlayer> list = GameManager.Instance.World.Players.list;
            if (list != null)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    EntityPlayer entityPlayer = list[i];
                    if (entityPlayer.entityId + "" == id)
                    {
                        return entityPlayer.EntityName;
                    }
                }
            }
            return "";
        }
    }
}
