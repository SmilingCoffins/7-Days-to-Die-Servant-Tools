﻿using ETbot_Mananger.HttpServerSlr.TelnetThreadIntface;
using System.Threading;
using System.Xml;
/*
 * 接口名：商店
 * 作用：玩家输入商店指令，输出商店物品
 */
namespace ETbot_Mananger.Telnet
{
    class Shop : TelnetThread
    {
        public override string Name()
        {
            return "商店";
        }

        public override void run()
        {
            SetPath("home.xml");
            string id = getID();

            XmlNode list = GetXml("SHOP");
            XmlNodeList zi = list.ChildNodes;

            foreach(XmlNode p in zi)
            {
                pmSend("ID:" + p.Attributes[0].Value+"积分:"+p.Attributes[2].Value +"数量:"+p.Attributes[3].Value +"介绍:"+ p.InnerText);
                Thread.Sleep(100);
            }
        }
    }
}
