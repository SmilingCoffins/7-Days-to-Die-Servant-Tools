﻿using ETbot_Mananger.HttpServerSlr;
using ETbot_Mananger.SayModular;
using Http.HttpServerSlr;
using System;
using System.Collections.Generic;

namespace ETbot_Mananger.Controls
{
    class API : IModApi
    {

        public static HttpServer_Intface server = null;
        public static TelnetServer telnet = null;                   //等待接受Api命令，开启telnet服务器
        public static Dao say = null;
        public static string GamePath = "Mods/XiaoyuBot/";          //基础目录的位置

        public static Dictionary<string, string> val = new Dictionary<string, string>();
        public void InitMod()
        {

            ModEvents.GameAwake.RegisterHandler(new Action(delegate
            {
                
                server = new HttpServer();                                           //Http服务器
                say = new Dao();                                                    //公告线程

            }));
           
            
        }
    }
}
