﻿using System;
using System.Collections.Generic;
/*
 * 接口名：pm
 * 作用：玩家输入pm指令，私信玩家
 */
namespace ETbot_Mananger.Api
{
    class SayToPlayer : ConsoleCmdAbstract
    {
        public override void Execute(List<string> _params, CommandSenderInfo _senderInfo)
        {
            ClientInfo clientInfo = ConsoleHelper.ParseParamIdOrName(_params[0], true, false);
            string message = _params[1];
            NetPackageChat cha = new NetPackageChat();
            NetPackageChat se = cha.Setup(EChatType.Whisper, -1, message, "[ff0000]管理员", false, null);
            clientInfo.SendPackage(se);
        }

        public override string[] GetCommands()
        {
            return new string[]
        {
            "pm"
        };
        }

        public override string GetDescription()
        {
            throw new NotImplementedException();
        }
    }
}
