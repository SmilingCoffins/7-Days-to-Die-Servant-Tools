﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
/*
 * 接口名：give
 * 作用：玩家输入give指令，发放物品
 */
namespace ETbot_Mananger.TelnetCmd
{
    class Give : ConsoleCmdAbstract
    {
		public override void Execute(List<string> _params, CommandSenderInfo _senderInfo)
		{
			try
			{
				if (_params.Count != 3 && _params.Count != 4)
				{
					SingletonMonoBehaviour<SdtdConsole>.Instance.Output("Wrong number of arguments, expected 3 or 4, found " + _params.Count + ".");
				}
				else
				{
					ClientInfo clientInfo = ConsoleHelper.ParseParamIdOrName(_params[0], true, false);
					if (clientInfo == null)
					{
						SingletonMonoBehaviour<SdtdConsole>.Instance.Output("Playername or entity id not found.");
					}
					else
					{
						ItemValue itemValue = ItemClass.GetItem(_params[1], true);
						if (itemValue.type == ItemValue.None.type)
						{
							SingletonMonoBehaviour<SdtdConsole>.Instance.Output("Item not found.");
						}
						else
						{
							itemValue = new ItemValue(itemValue.type, true);
							int num;
							if (!int.TryParse(_params[2], out num) || num <= 0)
							{
								SingletonMonoBehaviour<SdtdConsole>.Instance.Output("Amount is not an integer or not greater than zero.");
							}
							else
							{
								int num2 = 6;
								if (_params.Count == 4 && (!int.TryParse(_params[3], out num2) || num2 <= 0))
								{
									SingletonMonoBehaviour<SdtdConsole>.Instance.Output("Quality is not an integer or not greater than zero.");
								}
								else
								{
									if (ItemClass.list[itemValue.type].HasSubItems)
									{
										for (int i = 0; i < itemValue.Modifications.Length; i++)
										{
											ItemValue itemValue2 = itemValue.Modifications[i];
											itemValue2.Quality = num2;
											itemValue.Modifications[i] = itemValue2;
										}
									}
									else if (ItemClass.list[itemValue.type].HasQuality)
									{
										itemValue.Quality = num2;
									}
									EntityPlayer entityPlayer = GameManager.Instance.World.Players.dict[clientInfo.entityId];
									ItemStack itemStack = new ItemStack(itemValue, num);
									GameManager.Instance.ItemDropServer(itemStack, entityPlayer.GetPosition(), Vector3.zero, -1, 60f, false);
									SingletonMonoBehaviour<SdtdConsole>.Instance.Output("Dropped item");
								}
							}
						}
					}
				}
			}
			catch (Exception arg)
			{
				Log.Out("Error in Give.Run: " + arg);
			}
		}

		public override string[] GetCommands()
        {
            return new string[]
            {
                "give"
            };
        }

        public override string GetDescription()
        {
            throw new NotImplementedException();
        }
    }
}
