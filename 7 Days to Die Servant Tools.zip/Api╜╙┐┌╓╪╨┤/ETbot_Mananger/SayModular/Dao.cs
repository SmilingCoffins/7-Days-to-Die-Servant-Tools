﻿using ETbot_Mananger.Controls;
using Http.HttpServerSlr;
using System.Collections.Generic;
using System.Threading;
using System.Xml;

namespace ETbot_Mananger.SayModular
{
    class Dao
    {
        public Dao()
        {
            Init();
        }

        public Dictionary<string, strcatSayName> val = new Dictionary<string, strcatSayName>();

        //重新加载所有公告线程
        public void Init()
        {
            foreach (string i in val.Keys)
            {
                val[i].stop(); //结束所有线程
            }
            val.Clear();        //清空容器
            //处理Xml 读取所有公告
            XmlDocument root = new XmlDocument();
            root.Load(API.GamePath + "home.xml");
            XmlNode P1 = root.DocumentElement;
            foreach(XmlNode p in P1)
            {
                if(p.Name == "SAY")
                {
                    XmlNodeList P2 = p.ChildNodes;
                    foreach(XmlNode p2 in P2)
                    {
                        val.Add(p2.Attributes[0].Value, new strcatSayName(p2.Attributes[0].Value, p2.Attributes[1].Value, p2.Attributes[2].Value, p2.InnerText));
                    }
                }
            }
        }

    }
}
