﻿using ETbot_Mananger.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ETbot_Mananger.SayModular
{
    class strcatSayName
    {
        string id;
        int time;
        string state;
        string name;
        public string i = "true";
        public Thread thread;

        public strcatSayName(string id,string time,string state,string name)
        {
            this.id = id;
            this.time = (int)Double.Parse(time);
            this.state = state;
            this.name = name;

            if(state == "true")
            {
                //if state type true run Thread
                thread = new Thread(new ThreadStart(run));  //启动公告线程
                thread.Start();

            }

        }

        public void run()
        {
            while (i == "true")
            {
                Log.Out(i);
                Thread.Sleep(time);

                send(name);
            }
        }

        public void stop()
        {

            if (thread != null)
            {
                thread.Abort();
            }
        }

        public void send(string msg)
        {
            GameManager.Instance.ChatMessageServer(null, EChatType.Global, -1, msg, "[ff0000]公告", false, null);
        }
    }
}
