﻿using ETbot_Mananger.Controls;
using Http.Api;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace ETbot_Mananger.HttpModular.HttpApiSlr.Say
{
    class SetSay : HttpApi
    {
        public override string Name()
        {
            return "SetSay";
        }

		XmlDocument appSetting = new XmlDocument();

		public override void POST()
		{
			string id = getName("id");
			string time = getName("time");
			string state = getName("state");
			string name = getName("name");

			appSetting.Load(API.GamePath + "home.xml");
			getFunction(id, time,state,name);
			appSetting.Save(API.GamePath + "home.xml");
			Write("set OK");

			API.say.Init();
		}

		public string getFunction(string id, string time,string state,string name)
		{

			XmlNode pXmlNode = appSetting.DocumentElement;
			foreach (XmlNode p in pXmlNode)
			{
				if (p.Name == "SAY")
				{

					XmlNodeList zi = p.ChildNodes;

					foreach (XmlNode p1 in zi)
					{
						if (p1.Attributes[0].Value == id)
						{
							p1.Attributes[1].Value = time;
							p1.Attributes[2].Value = state;
							p1.InnerText = name;
						}
					}

				}
			}

			return "";
		}
	}
}
