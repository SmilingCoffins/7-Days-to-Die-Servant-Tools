﻿using ETbot_Mananger.Controls;
using Http.Api;
using System.Text;
using System.Xml;
/*
 *	接口名： AddShop
 *	作用：对商店的xml，进行添加操作，判断添加的ID值是否存在，存在返回id存在添加失败！
 * 
 */
namespace ETbot_Mananger.HttpServerApi.HttpApiSlr
{
	class AddSay : HttpApi
	{

		XmlDocument appSetting = new XmlDocument();

		public override void POST()
		{
			string id, name, jifen, leng;
			id = getName("id");
			name = getName("time");
			jifen = getName("state");
			leng = getName("name");
			/*取参*/

			appSetting.Load(API.GamePath + "home.xml"); //加载xml路径

			string buff = getFunction(id, name, jifen, leng);
			Write(buff);//添加返回内容
			appSetting.Save(API.GamePath + "home.xml"); //保存xml

			API.say.Init();
		}

		public string getFunction(string id, string time, string state, string name)
		{

			StringBuilder buf = new StringBuilder();

			XmlNode pXmlNode = appSetting.DocumentElement;

			XmlNode re = null;

			foreach (XmlNode p in pXmlNode)
			{
				if (p.Name == "SAY")
				{

					XmlNodeList zi = p.ChildNodes;
					re = p;
					foreach (XmlNode p1 in zi)
					{
						if (p1.Attributes[0].Value == id)
						{
							return "当前ID已存在";
						}
					}



				}
			}

			if (re != null)
			{
				XmlElement em = appSetting.CreateElement("name");
				em.SetAttribute("id", id);
				em.SetAttribute("time", time);
				em.SetAttribute("state", state);
				em.InnerText = name;

				re.AppendChild(em);
				return "添加成功！";
			}
			else
			{
				return "未找到!";
			}


		}

		public override string Name()
		{
			return "AddSay";
		}
	}
}
