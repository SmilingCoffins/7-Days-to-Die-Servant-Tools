﻿using ETbot_Mananger.Controls;
using Http.Api;
using System.Text;
using System.Xml;

/*
 *	接口名： DelShop
 *	作用：对商店的xml，进行删除操作！
 * 
 */

namespace ETbot_Mananger.HttpServerApi.HttpApiSlr
{
    class DelSay : HttpApi
	{

		XmlDocument appSetting = new XmlDocument();

		public override void POST()
		{
			string id, name, jifen, leng;
			id = getName("id");
			name = getName("time");
			jifen = getName("state");
			leng = getName("name");
			appSetting.Load(API.GamePath + "home.xml");
			string buff = getFunction(id, name, jifen, leng);
			Write(buff);
			appSetting.Save(API.GamePath + "home.xml");

			API.say.Init();
		}

		public string getFunction(string id, string time, string state, string name)
		{

			StringBuilder buf = new StringBuilder();

			XmlNode pXmlNode = appSetting.DocumentElement;

			XmlNode re = null;

			foreach (XmlNode p in pXmlNode)
			{
				if (p.Name == "SAY")
				{

					XmlNodeList zi = p.ChildNodes;
					re = p;
					foreach (XmlNode p1 in zi)
					{
						if (p1.Attributes[0].Value == id)
						{
							p.RemoveChild(p1);
							return "删除成功";
						}
					}



				}
			}

			return "未找到!";


		}

		public override string Name()
		{
			return "DelSay";
		}
	}
}
