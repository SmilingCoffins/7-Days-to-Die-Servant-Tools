﻿using ETbot_Mananger.Controls;
using Http.Api;
using System.Text;
using System.Xml;
/*
 *	接口名： SetShop
 *	作用：设置商店物品；
 * 
 */
namespace ETbot_Mananger.HttpServerApi.HttpApiSlr
{
    class SetShop : HttpApi
	{

		XmlDocument appSetting = new XmlDocument();

		public override void POST()
		{
			string id, name, jifen, leng, val;
			id = getName("id");
			name = getName("name");
			jifen = getName("jifen");
			leng = getName("leng");
			val = getName("val");
			appSetting.Load(API.GamePath + "home.xml");
			string buff = getFunction(id,name,jifen,leng,val);
			Write(buff);
			appSetting.Save(API.GamePath + "home.xml");
		}

		public string getFunction(string id,string name,string jifen,string len,string val)
		{

			StringBuilder buf = new StringBuilder();

			XmlNode pXmlNode = appSetting.DocumentElement;
			foreach (XmlNode p in pXmlNode)
			{
				if (p.Name == "SHOP")
				{

					XmlNodeList zi = p.ChildNodes;

					foreach (XmlNode p1 in zi)
					{
						if(p1.Attributes[0].Value == id)
                        {
							p1.Attributes[1].Value = name;
							p1.Attributes[2].Value = jifen;
							p1.Attributes[3].Value = len;
							p1.InnerText = val;
							return "修改成功！";
                        }
					}

				}
			}



			return "修改失败，请添加数据！";
		}

        public override string Name()
        {
            return "SetShop";
        }
    }
}
