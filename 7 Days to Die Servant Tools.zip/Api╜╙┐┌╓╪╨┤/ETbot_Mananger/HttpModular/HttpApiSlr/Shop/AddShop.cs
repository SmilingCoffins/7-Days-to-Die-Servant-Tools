﻿using ETbot_Mananger.Controls;
using Http.Api;
using System.Text;
using System.Xml;
/*
 *	接口名： AddShop
 *	作用：对商店的xml，进行添加操作，判断添加的ID值是否存在，存在返回id存在添加失败！
 * 
 */
namespace ETbot_Mananger.HttpServerApi.HttpApiSlr
{
    class AddShop : HttpApi
	{

		XmlDocument appSetting = new XmlDocument();

		public override void POST()
		{
			string id, name, jifen, leng, val;
			id = getName("id");
			name = getName("name");
			jifen = getName("jifen");
			leng = getName("leng");
			val = getName("val");
			/*取参*/

			appSetting.Load(API.GamePath + "home.xml");	//加载xml路径

			string buff = getFunction(id, name, jifen, leng, val);
			Write(buff);//添加返回内容
			appSetting.Save(API.GamePath + "home.xml");	//保存xml
		}

		public string getFunction(string id, string name, string jifen, string len, string val)
		{

			StringBuilder buf = new StringBuilder();

			XmlNode pXmlNode = appSetting.DocumentElement;

			XmlNode re = null;

			foreach (XmlNode p in pXmlNode)
			{
				if (p.Name == "SHOP")
				{

					XmlNodeList zi = p.ChildNodes;
					re = p;
					foreach (XmlNode p1 in zi)
					{
						if (p1.Attributes[0].Value == id)
						{
							return "当前ID已存在";
						}
					}

					

				}
			}

            if (re != null)
            {
				XmlElement em = appSetting.CreateElement("name");
				em.SetAttribute("id", id);
				em.SetAttribute("name", name);
				em.SetAttribute("jifen", jifen);
				em.SetAttribute("leng", len);
				em.InnerText = val;

				re.AppendChild(em);
				return "添加成功！";
            }
            else
            {
				return "未找到!";
            }

			
		}

        public override string Name()
        {
            return "AddShop";
        }
    }
}
