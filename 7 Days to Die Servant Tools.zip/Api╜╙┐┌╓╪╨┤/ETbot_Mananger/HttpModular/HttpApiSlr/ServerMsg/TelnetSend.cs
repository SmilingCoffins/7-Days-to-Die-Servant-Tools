﻿using Http.Api;
/*
 *	接口名： TelnetSend
 *	作用：调用Api.telnet类中的send函数，对telnet发送消息；
 * 
 */
namespace ETbot_Mananger.Controls
{
    class TelnetSend : HttpApi
    {
        public override string Name()
        {
            return "TelnetSend";
        }

        public override void POST()
        {
            string buf = getName("buf");
            if(API.telnet == null)
            {
                Write("Telnet未启动");
            }
            else
            {
                API.telnet.Send(buf);
                Write("success");
            }
            
        }
    }
}
