﻿using Http.Api;
/*
 *	接口名： SendMsg
 *	作用：接受对应字符串，调用游戏内的函数，以name的名称，发送msg数据给服务器，让所有人看到；
 * 
 */
namespace ETbot_Mananger.Controls
{
    class SendMsg : HttpApi
    {
        public override string Name()
        {
            return "SendMsg";
        }

        public override void POST()
        {
            string msg = getName("msg");
            string name = getName("name");
            GameManager.Instance.ChatMessageServer(null, EChatType.Global, -1, msg, "[ff0000]"+name, false, null);
            Write("say OK");
        }
    }
}
