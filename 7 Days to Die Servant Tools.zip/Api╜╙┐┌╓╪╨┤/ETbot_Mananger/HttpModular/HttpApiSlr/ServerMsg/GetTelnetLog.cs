﻿using Http.Api;
/*
 *	接口名： GetTelnetLog
 *	作用：判断API.telnet类中的 buf的值是否大于0，如果有值则返回，无值则null；
 * 
 */
namespace ETbot_Mananger.Controls
{
    class GetTelnetLog : HttpApi
    {
        public override string Name()
        {
            return "GetTelnetLog";
        }

        public override void POST()
        {
            if(API.telnet.buf.Length > 0)
            {
                Write(API.telnet.buf.ToString());
                API.telnet.buf.Length = 0;
            }
            else
            {
                Write("null");
            }
        }
    }
}
