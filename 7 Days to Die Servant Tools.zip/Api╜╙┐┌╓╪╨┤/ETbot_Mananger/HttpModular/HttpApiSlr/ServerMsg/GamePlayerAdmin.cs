﻿using Http.Api;
using System.Collections.Generic;
using System.Text;
/*
 *	接口名： GamePlayerAdmin
 *	作用：获取全部的玩家信息，进行string处理，返回！
 * 
 */
namespace ETbot_Mananger.Controls
{
    class GamePlayerAdmin : HttpApi
    {
        public override string Name()
        {
            return "GamePlayerAdmin";
        }

        public override void POST()
        {
			
				List<EntityPlayer> list = GameManager.Instance.World.Players.list;
				if (list != null)
				{
					StringBuilder stringBuilder = new StringBuilder();
					for (int i = 0; i < list.Count; i++)
					{
						EntityPlayer entityPlayer = list[i];
						string value = "<unknown>";
						string value2 = "<unknown>";
						ClientInfo clientInfo = SingletonMonoBehaviour<ConnectionManager>.Instance.Clients.ForEntityId(entityPlayer.entityId);
						if (clientInfo != null)
						{
							value = clientInfo.ip;
							value2 = clientInfo.playerId;
						}
						//stringBuilder.Append("游戏ID=");
						stringBuilder.Append(entityPlayer.entityId);
						stringBuilder.Append("|");
						stringBuilder.Append(entityPlayer.EntityName);
						stringBuilder.Append("|");
						stringBuilder.Append(entityPlayer.GetPosition().ToCultureInvariantString());
						stringBuilder.Append("|");
						stringBuilder.Append(entityPlayer.rotation.ToCultureInvariantString());
						stringBuilder.Append("|");
						stringBuilder.Append(entityPlayer.isEntityRemote);
						stringBuilder.Append("|");
						stringBuilder.Append(entityPlayer.Health);
						stringBuilder.Append("|");
						stringBuilder.Append(entityPlayer.Died);
						stringBuilder.Append("|");
						stringBuilder.Append(entityPlayer.KilledZombies);
						stringBuilder.Append("|");
						stringBuilder.Append(entityPlayer.KilledPlayers);
						stringBuilder.Append("|");
						stringBuilder.Append(entityPlayer.Score);
						stringBuilder.Append("|");
						stringBuilder.Append(entityPlayer.Progression.GetLevel());
						stringBuilder.Append("|");
						stringBuilder.Append(value2);
						stringBuilder.Append("|");
						stringBuilder.Append(value);
						stringBuilder.Append("|");
						stringBuilder.Append(entityPlayer.pingToServer);
						Write(stringBuilder.ToString() + "\r\n");
						stringBuilder.Length = 0;
					}
				}
			
		}
			
    }
}
