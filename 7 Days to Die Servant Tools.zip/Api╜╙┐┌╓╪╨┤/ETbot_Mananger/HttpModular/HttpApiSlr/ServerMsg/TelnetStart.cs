﻿using ETbot_Mananger.HttpServerSlr;
using Http.Api;
/*
 *	接口名： TelnetStart
 *	作用：对API.telnet类的null状态，生成实例；
 * 
 */
namespace ETbot_Mananger.Controls
{
    class TelnetStart : HttpApi
    {
        public override string Name()
        {
            return "TelnetStart";
        }

        public override void POST()
        {
            if(API.telnet == null)
            {
                API.telnet = new TelnetServer();
                Write("start");
            }
            else
            {
                Write("run");
            }

        }
    }
}
