﻿using Http.Api;
using System.Collections.Generic;
/*
 *	接口名： GetGameConfig
 *	作用：获取全部游戏配置，对特定的参数处理返回！
 * 
 */
namespace ETbot_Mananger.Controls
{
    class GetGameConfig : HttpApi
    {
        public override string Name()
        {
            return "GetGameConfig";
        }

        public override void POST()
        {
			List<string> list = new List<string>();
            if (list != null)
            {
                foreach (EnumGamePrefs enumGamePrefs in EnumUtils.Values<EnumGamePrefs>())
                {
                
                    list.Add(string.Format("GamePref.{0} = {1}", enumGamePrefs.ToStringCached<EnumGamePrefs>(), GamePrefs.GetObject(enumGamePrefs)) + "<br>");
                }

                foreach (string i in list)
                {
                    if (i.IndexOf("GamePref.ServerName") != -1)
                    {
                        Write("服务器名：" + i.Substring(i.IndexOf("=") + 1));
                    }
                    if (i.IndexOf("GamePref.GameName =") != -1)
                    {
                        Write("游戏名：" + i.Substring(i.IndexOf("=") + 1));
                    }
                    if (i.IndexOf("GamePref.ServerIP") != -1)
                    {
                        Write("游戏IP：" + i.Substring(i.IndexOf("=") + 1));
                    }
                    if (i.IndexOf("GamePref.ServerPort =") != -1)
                    {
                        Write("游戏端口：" + i.Substring(i.IndexOf("=") + 1));
                    }
                    if (i.IndexOf("GamePref.ServerMaxPlayerCount") != -1)
                    {
                        Write("最大玩家数量：" + i.Substring(i.IndexOf("=") + 1));
                    }
                    if (i.IndexOf("GamePref.GameVersion") != -1)
                    {
                        Write("服务器版本：" + i.Substring(i.IndexOf("=") + 1));
                    }
                    if (i.IndexOf("MaxSpawnedZombies") != -1)
                    {
                        Write("最大僵尸数量：" + i.Substring(i.IndexOf("=") + 1));
                    }
                    if (i.IndexOf("GamePref.SaveGameFolder") != -1)
                    {
                        Write("存档位置：" + i.Substring(i.IndexOf("=") + 1));
                    }
                    if (i.IndexOf("GamePref.WorldGenSize") != -1)
                    {
                        Write("地图大小：" + i.Substring(i.IndexOf("=") + 1));
                    }
                }
            }
			
	
		}
    }
}
