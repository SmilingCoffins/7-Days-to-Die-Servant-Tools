﻿using Http.Api;
/*
 *	接口名： InitXml
 *	作用：对功能进行修改以后，需要重新初始化telnet类中的val参数，不然get到对应的类；
 * 
 */
namespace ETbot_Mananger.Controls
{
    class InitXml : HttpApi
	{
        public override string Name()
        {
            return "InitXml";
        }

        public override void POST()
		{
			API.telnet.initZ();
			Write("intiXml OK");
		}
	}
}
