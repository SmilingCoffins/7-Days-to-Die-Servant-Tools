﻿using ETbot_Mananger.Controls;
using Http.Api;
using System.Xml;
/*
 *	接口名： SetFunctionType
 *	作用：设置xml的对应功能值，开启状态；
 * 
 */
namespace ETbot_Mananger.HttpServerApi.HttpApiSlr
{
    class SetFunctionType : HttpApi
    {
		XmlDocument appSetting = new XmlDocument();

		public override void POST()
        {
			string buff, type;
			buff = getName("buff");
			type = getName("type");
			appSetting.Load(API.GamePath + "home.xml");
			getFunction(buff, type);
			appSetting.Save(API.GamePath + "home.xml");
			Write("say OK");
        }

		public void getFunction(string buff,string type)
		{

			XmlNode pXmlNode = appSetting.DocumentElement;
			foreach (XmlNode p in pXmlNode)
			{
				if (p.Name == "FUNCTION")
				{

					XmlNodeList zi = p.ChildNodes;

					foreach (XmlNode p1 in zi)
					{
						if (p1.Attributes[0].Value == buff)
						{
							p1.Attributes[1].Value = type;
						}
					}


				}
			}

		}

        public override string Name()
        {
            return "SetFunctionType";
        }
    }
}
