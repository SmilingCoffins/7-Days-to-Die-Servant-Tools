﻿using ETbot_Mananger.Controls;
using Http.Api;
using System.Text;
using System.Xml;
/*
 *	接口名： GetFunctionType
 *	作用：获取xml中，所有的功能开启状态，处理string 返回！
 * 
 */
namespace ETbot_Mananger.HttpServerApi.HttpApiSlr
{
    class GetFunctionType : HttpApi
    {

		XmlDocument appSetting = new XmlDocument();

		public override void POST()
        {
			appSetting.Load(API.GamePath + "home.xml");
			string buff = getFunction();
			Write(buff);
        }

		public string getFunction()
		{

			StringBuilder buf = new StringBuilder();

			XmlNode pXmlNode = appSetting.DocumentElement;
			foreach (XmlNode p in pXmlNode)
			{
				if (p.Name == "FUNCTION")
				{

					XmlNodeList zi = p.ChildNodes;

					foreach (XmlNode p1 in zi)
					{
						buf.Append(p1.Attributes[0].Value + ":" + p1.Attributes[1].Value + ":" + p1.InnerText+"\r\n");
					}

					return buf.ToString();
				}
			}

			return "";
		}

        public override string Name()
        {
            return "GetFunctionType";
        }
    }
}
