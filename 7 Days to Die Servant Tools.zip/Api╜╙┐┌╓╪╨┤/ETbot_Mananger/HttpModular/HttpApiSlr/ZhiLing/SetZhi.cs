﻿using ETbot_Mananger.Controls;
using Http.Api;
using System.Xml;
/*
 *	接口名： SetZhi
 *	作用：设置指令；
 * 
 */
namespace ETbot_Mananger.HttpServerApi.HttpApiSlr
{
	class SetZhi : HttpApi
	{
		XmlDocument appSetting = new XmlDocument();

		public override void POST()
		{
			string id = getName("id");
			string name = getName("name");

			appSetting.Load(API.GamePath + "home.xml");
			getFunction(id, name);
			appSetting.Save(API.GamePath + "home.xml");
			Write("set OK");
			API.telnet.initZ();
		}

		public string getFunction(string id, string jifen)
		{

			XmlNode pXmlNode = appSetting.DocumentElement;
			foreach (XmlNode p in pXmlNode)
			{
				if (p.Name == "FUNCTION")
				{

					XmlNodeList zi = p.ChildNodes;

					foreach (XmlNode p1 in zi)
					{
						if (p1.Attributes[0].Value == id)
						{
							p1.InnerText = jifen;
						}
					}

				}
			}

			return "";
		}

		public override string Name()
		{
			return "SetZhi";
		}
	}
}
