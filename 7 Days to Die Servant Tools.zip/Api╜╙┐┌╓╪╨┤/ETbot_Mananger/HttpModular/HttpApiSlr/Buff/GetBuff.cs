﻿using Http.Api;
using System;
using System.Collections.Generic;
/*
 *	接口名： GetBuff
 *	作用：获取全部的buff信息，进行string处理，返回！
 * 
 */
namespace ETbot_Mananger.Controls
{
    class GetBuff : HttpApi
    {
        public override string Name()
        {
            return "GetBuff";
        }

        public override void POST()
        {
			SortedDictionary<string, BuffClass> sortedDictionary = new SortedDictionary<string, BuffClass>(BuffManager.Buffs, StringComparer.OrdinalIgnoreCase);
			SingletonMonoBehaviour<SdtdConsole>.Instance.Output("Available buffs:");
			foreach (KeyValuePair<string, BuffClass> keyValuePair in sortedDictionary)
			{
				if (keyValuePair.Key.Equals(keyValuePair.Value.LocalizedName))
				{
					Write(keyValuePair.Key+"\r\n");
				}
				else
				{
					Write(keyValuePair.Key+"\r\n");
				}

			}
		}
    }
}
