﻿using ETbot_Mananger.Controls;
using Http.Api;
using System.Xml;
/*
 *	接口名： SetJifen
 *	作用：设置玩家积分，修改积分数量；
 * 
 */
namespace ETbot_Mananger.HttpServerApi.HttpApiSlr
{
    class SetJifen : HttpApi
    {
		XmlDocument appSetting = new XmlDocument();

		public override void POST()
		{
			string id = getName("id");
			string jifen = getName("jifen");

			appSetting.Load(API.GamePath + "home.xml");
			getFunction(id,jifen);
			appSetting.Save(API.GamePath + "home.xml");
			Write("set OK");
		}

		public string getFunction(string id,string jifen)
		{

			XmlNode pXmlNode = appSetting.DocumentElement;
			foreach (XmlNode p in pXmlNode)
			{
				if (p.Name == "JIFEN")
				{

					XmlNodeList zi = p.ChildNodes;

					foreach (XmlNode p1 in zi)
					{
						if(p1.Attributes[0].Value == id)
                        {
							p1.InnerText = jifen;
                        }
					}

				}
			}

			return "";
		}

        public override string Name()
        {
            return "SetJifen";
        }
    }
}
