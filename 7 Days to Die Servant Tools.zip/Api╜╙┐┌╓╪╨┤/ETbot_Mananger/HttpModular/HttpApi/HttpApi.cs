﻿using Http.HttpServerSlr;
using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Text;

namespace Http.Api
{

    public abstract class HttpApi
	{

		public Socket socket;   //用作链接的Socket
		string type;            //传入的请求
		public string mess;		//传入的信息
		Dictionary<string, string> val = new Dictionary<string, string>();	//对传入的值进行处理
		StringBuilder respBuf = new StringBuilder();							//返回值的处理
		
		public void setHttpApi(Socket socket,string type,string mess)
		{
			this.socket = socket;
			this.type = type;
			this.mess = mess;
			if(type == "POST")
			{
				string _buf = getData();

				getVal(_buf);

				GetRespApi();   //添加基础头

				//new Thread(new ThreadStart(POST)).Start();
				try
				{
					POST();		//执行post函数
				}catch(Exception e)
				{
					Write(e.Message);
				}

				socket.Send(System.Text.Encoding.UTF8.GetBytes(respBuf.ToString()));	//post执行完毕，将添加完的参数 全部发送

				socket.Close();															//关闭socket，api处理结束
			}
			else
			{
				socket.Send(AjaxHandle.GetRetuHead("请求方式需要为POST", ""));
			}
		}

		//处理接口
		public abstract void POST();
		//api名定义接口
		public abstract string Name();

		//取出请求最后一行的参数值
		private string getData()
		{
			string temp = mess;
			
			while (temp.IndexOf("\r\n") != -1)
			{
				temp = temp.Substring(temp.IndexOf("\r\n")+2);
			}

			return temp;
		}
		//返回参数
		public string getName(string _buf)
		{
			if (val.ContainsKey(_buf))
			{
				return val[_buf];
			}
			else
			{
				return "";
			}
		}
		//添加返回头-注意一旦调用Write函数，就不能在使用setRespHead函数了
		public void setRespHead(string _buf)
		{
			respBuf.Append(_buf+"\r\n");
		}
		//添加返回协议
		public void Write(string _buf)
		{
			if (respBuf.ToString().IndexOf("\r\n\r\n") != -1)
			{
				respBuf.Append(_buf);
			}
			else
			{
				respBuf.Append("\r\n");
				respBuf.Append(_buf);
			}
			
		}
		//对取出的参数值进行分割处理，储存到val中
		private void getVal(string _buf)
		{

			if(_buf.IndexOf("&") == -1)
			{
				if (_buf.IndexOf("=") != -1)
				{
					string[] temp = _buf.Split('=');
					if(temp[0].Length > 0 && temp[1].Length > 0)
					{
						val.Add(temp[0], temp[1]);
					}
				}
			}
			else
			{
				string[] temp = _buf.Split('&');
				for(int i = 0; i < temp.Length; i++)
				{
					if (temp[i].IndexOf("=") != -1)
					{
						string[] t = temp[i].Split('=');
						if(t[0].Length>0 && t[1].Length > 0)
						{
							val.Add(t[0], t[1]);
						}
					}
				}
			}

		}	
		//添加基础的Api返回协议头
		public void GetRespApi()
		{

			respBuf.Append("HTTP/1.1 200 OK \r\n");

			respBuf.Append("Content-Type: text/plain; charset=utf-8\r\n");

		}

	}

   
}
