﻿using Http.HttpServerSlr;
using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Reflection;

namespace Http.Api
{
	public class Factory
	{

		Socket socket;  //传入工长的socket
		string type;    //传入的http请求类型 post or get
		string mess;	//传入的http信息
		string api;		//传入的请求api
		
		public Factory(Socket socket,string type,string mess,string api)
		{
			this.socket = socket;
			this.type = type;
			this.mess = mess;
			this.api = api;

			var API = LoadBuffScript(typeof(HttpApi));      //加载HttpApi抽象的所有实现类 并获取类对应的参数，作为api索引

            if (API.ContainsKey(api))
            {
				Object Se = Activator.CreateInstance(API[api]);			//对该类进行实现
				MethodInfo method = API[api].GetMethod("setHttpApi");	//加载函数SetHttpApi
				object[] obj =											//设置参数
				{
				 socket,
				 type,
				 mess
				};

				method.Invoke(Se, obj);									//启动线程处理api请求
			}
			else
			{
				socket.Send(AjaxHandle.GetRetuHead("请求参数非法", ""));
			}

		}

		public Dictionary<string, Type> LoadBuffScript(Type _type)
		{
			Dictionary<string, Type> list = new Dictionary<string, Type>();
			var types = Assembly.GetCallingAssembly().GetTypes();
			//var aType = typeof(IBuffControl);
			var aType = _type;
			foreach (var type in types)
			{
				var baseType = type.BaseType;  //获取基类
				while (baseType != null)  //获取所有基类
				{
					//Debug.Log(baseType.Name);
					if (baseType.Name == aType.Name)
					{
						Type objtype = Type.GetType(type.FullName, true);
						//object obj = Activator.CreateInstance(objtype);
						//if (obj != null)
						//{
						//SeekTarget info = obj as SeekTarget;
						Object Se = Activator.CreateInstance(objtype);

						MethodInfo method = objtype.GetMethod("Name");//functionname:方法名字

						string str = (string)method.Invoke(Se, null);

						list.Add(str, objtype);
						//}
						break;
					}
					else
					{
						baseType = baseType.BaseType;
					}
				}

			}
			return list;
		}

	}

	
}
