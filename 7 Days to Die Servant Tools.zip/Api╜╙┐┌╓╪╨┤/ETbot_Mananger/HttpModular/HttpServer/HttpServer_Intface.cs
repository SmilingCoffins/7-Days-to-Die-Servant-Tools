﻿using ETbot_Mananger.Controls;
using System.Collections.Generic;
using System.Threading;

namespace Http.HttpServerSlr
{
    public abstract class HttpServer_Intface
    {

        public string _ip = "127.0.0.1";       //绑定本机的IP地址
        public int _port;                     //启动server的port
        public string path;                     //地址

        public HttpServer_Intface()
        {

            _port = 8083;
            path = API.GamePath+"Data/";

            Dictionary<string,string> val = AjaxHandle.GetPath(API.GamePath+"server.config");       //调用ajaxhandle 获取server.config配置文件中的port
            if (val != null)
            {
                if (val.ContainsKey("port") && val.ContainsKey("path"))
                {
                    _port = int.Parse(val["port"]);
                    path = val["path"];
                }
            }
            

            Thread _thread = new Thread(new ThreadStart(run));       //启动Http服务器线程  抽象出run方法，由httpserver继承，实现
            _thread.Start();
        }

        public abstract void run();     //Http线程启动方法

    }
}
