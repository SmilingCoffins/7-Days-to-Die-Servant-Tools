﻿using System.Collections.Generic;
using System.IO;
using System.Text;
/*
 对Ajax的传递参数处理
 */
namespace Http.HttpServerSlr
{
    public class AjaxHandle
    {
        //获取server.config,获取端口以及对应的path路径
        public static Dictionary<string,string> GetPath(string _path)
        {
            Dictionary<string, string> val = new Dictionary<string, string>();
            //首处理获取游戏存档位置
            if (File.Exists(_path))
            {
                FileStream fls = new FileStream(_path, FileMode.Open);
                byte[] file = new byte[fls.Length];

                int len = fls.Read(file, 0, (int)fls.Length);

                string path = System.Text.Encoding.UTF8.GetString(file);

                if (path.IndexOf("\r\n") != -1)
                {
                    string[] tp = path.Split(new char[] { '\r','\n' });
                    for(int i = 0; i < tp.Length; i++)
                    {
                        if (tp[i].IndexOf("=") != -1)
                        {
                            val.Add(tp[i].Split('=')[0], tp[i].Split('=')[1]);
                        }
                    }
                }
                else
                {
                    if (path.IndexOf("=") != -1)
                    {
                        val.Add(path.Split('=')[0], path.Split('=')[1]);
                    }
                    else
                    {
                        fls.Close();
                        return null;
                    }
                }
                fls.Close();
                return val;
            }
            else
            {
                return null;
            }
        }
        
        //获取请求的类型
        public static string GetRespType(string _buff)
        {
            if(_buff.Length > 0)
            {
                if(_buff.IndexOf(" ") != -1)
                {
                    return _buff.Substring(0, _buff.IndexOf(" "));
                }
                else
                {
                    return "";
                }
            }
            else
            {
                return "";
            }
        }

        //获取请求的URL
        public static string GetRespHead(string _buff)
        {
            if (_buff.Length > 0)
            {
                if (_buff.IndexOf("\r\n", 2) != 0)
                {
                    return _buff.Substring(0, _buff.IndexOf("\r\n", 2));
                }
                else
                {
                    return "";
                }
            }
            else
            {
                return "";
            }
        }

        //获取请求的url
        public static string GetRespUrl(string _buff)
        {
            if (_buff.Length > 0)
            {
                if(_buff.IndexOf(" ") != 0)
                {
                    return _buff.Split(' ')[1];
                }
                else
                {
                    return "";
                }
            }
            else
            {
                return "";
            }
        }

        //获取请求的文件后缀
        public static string GetSuffix(string _buf)
        {
            if (_buf.Length > 0)
            {
                if (_buf.IndexOf(".") != 0)
                {
                    while (_buf.IndexOf(".") != -1)
                    {
                        _buf = _buf.Substring(_buf.IndexOf(".") + 1);
                    }
                    return _buf;
                }
                else
                {
                    return "txt";
                }
            }
            else
            {
                return "txt";
            }
        }

        //返回对应的后缀协议头，以及http协议头
        public static byte[] GetRetuHead(string _buf,string _suffix)
        {
            StringBuilder buf = new StringBuilder();
            buf.Append("HTTP/1.1 200 OK \r\n");
            switch (_suffix)
            {
                case "html":
                    buf.Append("Content-Type: text/html; ");
                    break;
                case "txt":
                    buf.Append("Content-Type: text/plain; ");
                    break;
                case "jpg":
                    buf.Append("Content-Type: image/jpeg; ");
                    break;
                case "png":
                    buf.Append("Content-Type: image/png; ");
                    break;
                case "zip":
                    buf.Append("Content-Type: application/zip; ");
                    break;
                case "pdf":
                    buf.Append("Content-Type: application/pdf; ");
                    break;
                case "mp3":
                    buf.Append("Content-Type: audio/mpeg; ");
                    break;
                case "css":
                    buf.Append("Content-Type: text/css; ");
                    break;
                case "js":
                    buf.Append("Content-Type: text/javascript; ");
                    break;
                case "xml":
                    buf.Append("Content-Type: text/xml; ");
                    break;

                default:
                    buf.Append("Content-Type: text/plain; ");
                    break;
            }

            buf.Append("charset=utf-8\r\n");                        //返回UTF-8字符集
            buf.Append("Access-Control-Allow-Origin: *\r\n\r\n");   //解除跨域限制
            buf.Append(_buf);                                       //添加进传入参数
            byte[] write = System.Text.Encoding.UTF8.GetBytes(buf.ToString());
            return write;
        }

    }
}
