﻿using Http.Api;
using Http.HttpServerSlr;
using System.IO;
using System.Net.Sockets;
using System.Threading;

namespace ConsoleApp2.HttpServerSlr
{
    public class HttpFind
    {

        Socket socket;
        string path;
        //获取server类传入的参数，开启run线程
        public HttpFind(Socket socket,string path)
        {
            this.path = path;
            this.socket = socket;
            new Thread(new ThreadStart(run)).Start();

        }
        //run 对传入参数处理，并提交工厂类生成实例！API            如果为正常的文件，则调用file将byte[]数组返回
        public void run()
        {

            byte[] head = new byte[1024];

            int len = socket.Receive(head);

            string body = System.Text.Encoding.UTF8.GetString(head, 0, len);     //取出传入参数

            string respUrl = AjaxHandle.GetRespHead(body);

            string type = AjaxHandle.GetRespType(respUrl);

            string url = AjaxHandle.GetRespUrl(respUrl);

            bool api = false;

            //判断url请求的地址是否是api

            if (url.Length > 4)
            {
                string temp = url.Substring(0, 4);

                if (temp == "/api")
                {
                    //准备进入api接口
                    if (url.Length > 5)
                    {
                        string API = url.Substring(5);
                        new Factory(socket, type, body, API);
                    }
                    else
                    {
                        socket.Send(AjaxHandle.GetRetuHead("请求接口不存在", ""));
                    }
                    api = true;
                }

            }

            //如果请求类型不为api ，则使用file返回byte数组
            if (api == false)
            {
                if (File.Exists(path + url))
                {
                    //正常读文件
                    string suffix = AjaxHandle.GetSuffix(url);
                    byte[] respHead = AjaxHandle.GetRetuHead("", suffix);

                    FileStream fls = new FileStream(path + url, FileMode.Open);

                    byte[] file = new byte[fls.Length];

                    int count = fls.Read(file, 0, (int)fls.Length);

                    byte[] respFile = new byte[respHead.Length + fls.Length];

                    respHead.CopyTo(respFile, 0);
                    file.CopyTo(respFile, respHead.Length);

                    socket.Send(respFile);
                    fls.Close();
                }
                else
                {
                    socket.Send(AjaxHandle.GetRetuHead(path + url + ":404", ""));
                }


            }




            socket.Close();
        }
    }
}
