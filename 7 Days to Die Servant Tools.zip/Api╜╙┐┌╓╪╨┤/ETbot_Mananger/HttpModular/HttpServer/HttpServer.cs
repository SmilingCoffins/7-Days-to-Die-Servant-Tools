﻿using ConsoleApp2.HttpServerSlr;
using System;
using System.Net;
using System.Net.Sockets;

namespace Http.HttpServerSlr
{
    public class HttpServer : HttpServer_Intface
    {
        //run 启动http服务器
        public override void run()
        {
            try
            {
                //绑定socket端口
                Socket server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                IPEndPoint addr = new IPEndPoint(IPAddress.Parse(_ip), _port);
                server.Bind(addr);
                server.Listen(0);
                //开始循环阻塞接受新的appept socket
                while (true)
                {
                    Socket socket = server.Accept();        //监听消息
                    new HttpFind(socket,path);              //启动线程处理这条消息

                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }
    }
}
