$(document).ready(function (){

    $("#say_init").click(function (){
        say_init();
    });

    $("#say_xiu").click(function (){
        $.ajax({
            url:"/api/SetSay",
            type:"post",
            data:"id="+$("#say_id").val()+"&time="+$("#say_time").val()+"&state="+$("#say_state").val()+"&name="+$("#say_name").val(),
            success:function (data){
                say_init();
            }
        })
    });

    $("#say_add").click(function (){
        $.ajax({
            url:"/api/AddSay",
            type:"post",
            data:"id="+$("#say_id").val()+"&time="+$("#say_time").val()+"&state="+$("#say_state").val()+"&name="+$("#say_name").val(),
            success:function (data){
                say_init();
            }
        })
    });

    $("#say_del").click(function (){
        $.ajax({
            url:"/api/DelSay",
            type:"post",
            data:"id="+$("#say_id").val()+"&time="+$("#say_time").val()+"&state="+$("#say_state").val()+"&name="+$("#say_name").val(),
            success:function (data){
                say_init();
            }
        })
    });
});

function say_init(){
    $.ajax({
        url:"/api/GetSay",
        type:"post",
        success:function (data){
            if(data!=null){

                str1 = data.split("\r\n");

                var say = $("#say_shop");
                say.html("");   //init Table

                say.append("<tr>" +
                    "<th>ID</th>" +
                    "<th>时间(毫秒)</th>" +
                    "<th>状态</th>" +
                    "<th>内容</th>" +
                    "</tr>");

                for(i=0;i<str1.length-1;i++){
                    str2 = str1[i].split(":");
                    say.append("<tr onclick='say_set(\""+str2[0]+"\",\""+str2[1]+"\",\""+str2[2]+"\",\""+str2[3]+"\")'>" +
                        "<th>"+str2[0]+"</th>" +
                        "<th>"+str2[1]+"</th>" +
                        "<th>"+str2[2]+"</th>" +
                        "<th>"+str2[3]+"</th>" +
                        "</tr>")
                }

            }
        }
    });
}

function say_set(id,time,state,name){
    $("#say_id").val(id);
    $("#say_time").val(time);
    $("#say_state").val(state);
    $("#say_name").val(name);
}