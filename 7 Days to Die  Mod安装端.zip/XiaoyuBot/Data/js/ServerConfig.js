$(document).ready(function (){
   //准备访问GetGameConfig接口

   $.ajax({
       url:"/api/GetGameConfig",
       type:'post',
       success: function (data){
           $("#GameConfig").append(data);
       }
   });

});
