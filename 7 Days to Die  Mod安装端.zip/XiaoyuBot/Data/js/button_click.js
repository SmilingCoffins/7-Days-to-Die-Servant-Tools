
$(document).ready(function (){
    b = new button();
    b.setVal(8);    //初始化容器加载
});

function hide_s(leng){
    for(let i=1;i<=leng;i++){
        $("#B"+i).hide();
    }
}











class button{

    leng;

    //获取全部的参数 进行绑定
    setVal(event){
        this.leng = event;
        for(let i=1;i<=this.leng;i++){
            $("#A"+i).bind("click",{index:i,leng:this.leng},this.clickHandle);
            $("#A"+i).bind("mouseover",function (){
               $("#A"+i).css("background-color","rgba(17,65,98,0.9)");
            });
            $("#A"+i).bind("mouseout",function (){
               $("#A"+i).css("background-color","rgba(255,215,0,0.8)");
            });
        }
        hide_s(this.leng);
        $("#B1").show();
    }

    clickHandle(event){
        hide_s(event.data.leng);
        $("#B"+event.data.index).show();
    }

}