$(document).ready(function (){
    //循环获取服务器Log
    setInterval(function (){
        $.ajax({
            url:"/api/GetTelnetLog",
            type:'post',
            success:function (data){
                if(data != "null") {
                    $("#ServerLog").append(data);
                    var divscll = document.getElementById('ServerLog');
                    divscll.scrollTop = divscll.scrollHeight;
                }
            }
        })
    },5000);
    //启动Telnet
    $("#startTelnet").click(function (){
        $.ajax({
            url:"/api/TelnetStart",
            type:"post",
            success:function (data){
                if(data=="run"){
                    $("#ServerLog").append("Telnet运行中\r\n");
                }
                if(data=="start"){
                    $("#ServerLog").append("Telnet启动成功\r\n");
                }
            }
        })
    });
    //发送Telnet指令到服务器
    $("#TelnetSumbut").click(function (){
        $.ajax({
            url:"/api/TelnetSend",
            type:'post',
            data:"buf="+$("#TelnetBuf").val(),
            success:function (data){
                $("#ServerLog").append(data+"\r\n");
                $("#TelnetBuf").val("");
            }
        })
    });

    $("#TelnetSumbutMsg").click(function (){
        $.ajax({
            url:"/api/SendMsg",
            type:'post',
            data:"msg="+$("#TelnetMsg").val()+"&name="+$("#TelnetName").val(),
            success:function (data){
                $("#ServerLog").append(data+"\r\n");
                $("#TelnetMsg").val("");
            }
        })
    });
});