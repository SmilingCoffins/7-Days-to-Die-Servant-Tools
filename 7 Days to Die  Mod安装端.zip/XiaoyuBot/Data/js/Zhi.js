$(document).ready(function (){

    $("#config_init").click(function (){
        E();
    });
    $("#config_set").click(function (){
        $.ajax({
            url:"/api/SetZhi",
            type:"post",
            data:"id="+$("#config_id").val()+"&name="+$("#config_name").val(),
            success:function (data){
                E();
            }
        })
    });
});

function F(id,state,name){
    $("#config_id").val(id);
    $("#config_state").val(state);
    $("#config_name").val(name);
}

function E(){
    $.ajax({
        url:"/api/GetZhi",
        type:"post",
        success:function (data){
            $("#config_zhiling").html("");
            $("#config_zhiling").append("<tr>" +
                "<td>功能</td>" +
                "<td>状态</td>" +
                "<td>指令</td>" +
                "</tr>");

            if(data != ""){
                if(data!=""){
                    str1 = data.split("\r\n");
                    for(i = 0;i<str1.length-1;i++){
                        $("#config_zhiling").append("<tr onclick='F(\""+str1[i].split(":")[0]+"\",\""+str1[i].split(":")[1]+"\",\""+str1[i].split(":")[2]+"\")'>" +
                            "<th>"+str1[i].split(":")[0]+"</th>" +
                            "<th>"+str1[i].split(":")[1]+"</th>" +
                            "<th>"+str1[i].split(":")[2]+"</th>" +
                            "</tr>")
                    }
                }
            }
        }
    })
}




