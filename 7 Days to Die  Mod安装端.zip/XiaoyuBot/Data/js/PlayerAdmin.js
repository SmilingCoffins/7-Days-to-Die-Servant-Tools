function initDiv(){
    $("#player").html("");
    $("#player").append(" <tr>\n" +
        "                    <th>短ID</th>\n" +
        "                    <th>玩家名</th>\n" +
        "                    <th>位置</th>\n" +
        "                    <th>rot</th>\n" +
        "                    <th>romote</th>\n" +
        "                    <th>血量</th>\n" +
        "                    <th>死亡次数</th>\n" +
        "                    <th>击杀丧尸</th>\n" +
        "                    <th>击杀玩家</th>\n" +
        "                    <th>分数</th>\n" +
        "                    <th>等级</th>\n" +
        "                    <th>SteamID</th>\n" +
        "                    <th>IP</th>\n" +
        "                    <th>PING</th>\n" +
        "                </tr>");
}

//将点击的玩家ID传入 setID框架内
function setID(i){
    $("#setID").val(i);
}

$(document).ready(function (){
    setInterval(function (){
        $.ajax({
            url:"/api/GamePlayerAdmin",
            type:"post",
            success:function (data){

                if(data==""){
                    initDiv();
                }else{
                    initDiv();
                    s = data.split("\r\n");

                    for(i=0;i<s.length-1;i++){
                        str = s[i].split("|");

                        $("#player").append(" <tr onclick='setID(\""+str[0]+"\")'>\n" +
                            "                    <th>"+str[0]+"</th>\n" +
                            "                    <th>"+str[1]+"</th>\n" +
                            "                    <th>"+str[2]+"</th>\n" +
                            "                    <th>"+str[3]+"</th>\n" +
                            "                    <th>"+str[4]+"</th>\n" +
                            "                    <th>"+str[5]+"</th>\n" +
                            "                    <th>"+str[6]+"</th>\n" +
                            "                    <th>"+str[7]+"</th>\n" +
                            "                    <th>"+str[8]+"</th>\n" +
                            "                    <th>"+str[9]+"</th>\n" +
                            "                    <th>"+str[10]+"</th>\n" +
                            "                    <th>"+str[11]+"</th>\n" +
                            "                    <th>"+str[12]+"</th>\n" +
                            "                    <th>"+str[13]+"</th>\n" +
                            "                </tr>");
                    }

                }


            }
        })
    },5000) ;

});


function sendTel(i){
    id = $("#setID").val();

    if(i == "admin add"){
        i = "admin add "+id+" 0";
    }

    if(i == "admin remove"){
        i = "admin remove "+id;
    }

    if(i == "kill"){
        i = "kill "+id;
    }

    if(i == "delLing"){

    }

    if(i == "si"){
        i = "si "+id;
        alert("暂未完成！");
        return;
    }

    if(i=="buff"){
        i = "buffplayer "+id+" "+$("#buff").val();
    }

    if(i=="debuff"){
        i = "debuffplayer "+id+" "+$("#buff").val();
    }

    if(i == "initBuff"){
        $("#buff").click(function (){
            $.ajax({
                url:"/api/GetBuff",
                type:"post",
                success:function (data){
                    if(data!=""){
                        str = data.split("\r\n");
                        for(i=0;i<str.length;i++){
                            $("#buff").append("<option value=\""+str[i]+"\">"+str[i]+"</option>");
                        }
                    }
                }
            })
        });
        return;
    }

    $.ajax({
        url:"/api/TelnetSend",
        type:'post',
        data:"buf="+i,
        success:function (data){
            $("#ServerLog").append(data+"\r\n");
        }
    })
}