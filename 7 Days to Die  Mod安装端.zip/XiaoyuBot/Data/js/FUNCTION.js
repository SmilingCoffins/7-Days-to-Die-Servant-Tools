$(document).ready(function (){
    $.ajax({
        url:"/api/GetFunctionType",
        type: "post",
        success:function (data){
            if(data!=""){
                str1 = data.split("\r\n");
                for(i = 0;i<str1.length;i++){
                    str2 = str1[i].split(":");
                    if(str2[1] == "true"){
                        $("#"+str2[0]).attr("checked","true");
                    }
                }
            }
        }
    });
});

function setFunctionType(i){

    ty = $("#"+i).get(0).checked;

    $.ajax({
        url:"/api/SetFunctionType",
        type: "post",
        data:"buff="+i+"&type="+ty,
        success:function (data){
            if(data!=""){
                $.ajax({
                    url:"/api/InitXml",
                    type: "post",
                });
            }
        }
    });
}