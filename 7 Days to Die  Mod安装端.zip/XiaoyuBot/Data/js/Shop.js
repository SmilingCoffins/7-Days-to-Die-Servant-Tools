$(document).ready(function (){
    $("#xiu").click(function (){
        $.ajax({
            url:"/api/SetShop",
            type:"post",
            data:"id="+$("#S_id").val()+"&name="+$("#S_name").val()+"&jifen="+$("#S_jifen").val()+"&leng="+$("#S_leng").val()+"&val="+$("#S_val").val(),
            success:function (data){
                C();
            }
        })
    });

    $("#add").click(function (){
        $.ajax({
            url:"/api/AddShop",
            type:"post",
            data:"id="+$("#S_id").val()+"&name="+$("#S_name").val()+"&jifen="+$("#S_jifen").val()+"&leng="+$("#S_leng").val()+"&val="+$("#S_val").val(),
            success:function (data){
                if(data == "当前ID已存在"){
                    alert("当前物品序号已存在！");
                }
                C();
            }
        })
    });
    $("#del").click(function (){
        $.ajax({
            url:"/api/DelShop",
            type:"post",
            data:"id="+$("#S_id").val()+"&name="+$("#S_name").val()+"&jifen="+$("#S_jifen").val()+"&leng="+$("#S_leng").val()+"&val="+$("#S_val").val(),
            success:function (data){
                C();
            }
        })
    });

    $("#initShop").click(function (){
        C();
    });
});

function C(){
    $.ajax({
        url:"/api/GetShop",
        type: "post",
        success:function (data){
            $("#server_shop").html(""); //清空
            $("#server_shop").append("<tr>" +
                "<th>id</th>" +
                "<th>物品名</th>" +
                "<th>积分数量</th>" +
                "<th>个数</th>" +
                "<th>描述</th>" +
                "</tr>");

            if(data!=""){
                str1 = data.split("\r\n");
                for(i = 0;i<str1.length-1;i++){
                    $("#server_shop").append("<tr onclick='D(\""+str1[i].split(":")[0]+"\",\""+str1[i].split(":")[1]+"\",\""+str1[i].split(":")[2]+"\",\""+str1[i].split(":")[3]+"\",\""+str1[i].split(":")[4]+"\")'>" +
                        "<th>"+str1[i].split(":")[0]+"</th>" +
                        "<th>"+str1[i].split(":")[1]+"</th>" +
                        "<th>"+str1[i].split(":")[2]+"</th>" +
                        "<th>"+str1[i].split(":")[3]+"</th>" +
                        "<th>"+str1[i].split(":")[4]+"</th>" +
                        "</tr>")
                }
            }
        }
    });
}

function D(id,name,jifen,leng,val){
    $("#S_id").val(id);
    $("#S_name").val(name);
    $("#S_jifen").val(jifen);
    $("#S_leng").val(leng);
    $("#S_val").val(val);
}