$(document).ready(function (){
    $("#initJifen").click(function (){
        B();
    });

    $("#player_sub").click(function (){
        $.ajax({
            url:"/api/SetJifen",
            type: "post",
            data:"id="+$("#player_id").val()+"&jifen="+$("#player_val").val(),
            success:function (data){
                B();
            }
        });
    });
});

function B(){
    $.ajax({
        url:"/api/GetJifen",
        type: "post",
        success:function (data){
            $("#player_jifen").html(""); //清空
            $("#player_jifen").append("<tr>" +
                "<th>id</th>" +
                "<th>签到日期</th>" +
                "<th>积分数量</th>" +
                "</tr>");

            if(data!=""){
                str1 = data.split("\r\n");
                for(i = 0;i<str1.length-1;i++){
                    $("#player_jifen").append("<tr onclick='A(\""+str1[i].split(":")[0]+"\",\""+str1[i].split(":")[2]+"\")'>" +
                        "<th>"+str1[i].split(":")[0]+"</th>" +
                        "<th>"+str1[i].split(":")[1]+"</th>" +
                        "<th>"+str1[i].split(":")[2]+"</th>" +
                        "</tr>")
                }
            }
        }
    });
}

function A(i,ii){
    $("#player_id").val(i);
    $("#player_val").val(ii);
}